using System;
using System.Diagnostics;
using UnityEngine;

namespace CustomInspector
{
    /// <summary>
    /// A version of unitys [Space]-attribute but as PropertyAttrbute instead of DecoratorDrawer
    /// </summary>
    [AttributeUsage(AttributeTargets.Field, AllowMultiple = true)]
    [Conditional("UNITY_EDITOR")]
    public class Space2Attribute : ComparablePropertyAttribute
    {
        /// <summary>The distance in pixel</summary>
        public readonly float pixels;
        private Space2Attribute()
        {
            order = -10;
        }
        public Space2Attribute(float pixels) : this()
        {
            this.pixels = Mathf.Max(pixels, 0);
        }

        protected override object[] GetParameters() => new object[] { pixels };
    }
}
