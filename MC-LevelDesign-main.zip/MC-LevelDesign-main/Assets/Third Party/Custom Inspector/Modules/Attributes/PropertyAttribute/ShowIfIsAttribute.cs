using System;
using System.Diagnostics;


namespace CustomInspector
{

    /// <summary>
    /// Show field, if field (given by path/name) is equal to given value
    /// </summary>
    [AttributeUsage(AttributeTargets.Field, AllowMultiple = true)]
    [Conditional("UNITY_EDITOR")]
    public class ShowIfIsAttribute : ComparablePropertyAttribute
    {
        public readonly string fieldPath;
        public readonly object value;
        public DisabledStyle style = DisabledStyle.Invisible;
        /// <summary>
        /// The offset in the inspector applied on the member (to the right side)
        /// </summary>
        public int indent = 1;

        public bool Inverted { get; protected set; } = false;

        public ShowIfIsAttribute(string fieldPath, object value)
        {
            order = -10;
            this.fieldPath = fieldPath;
            this.value = value;
        }

        protected override object[] GetParameters() => new object[] { fieldPath, value, Inverted };
    }
    /// <summary>
    /// Show field, if field (given by path/name) is not equal to given value
    /// </summary>
    [AttributeUsage(AttributeTargets.Field, AllowMultiple = true)]
    [Conditional("UNITY_EDITOR")]
    public class ShowIfIsNotAttribute : ShowIfIsAttribute
    {
        public ShowIfIsNotAttribute(string fieldPath, object value) : base(fieldPath, value)
        {
            base.Inverted = true;
        }
    }
}