using CustomInspector.Extensions;
using CustomInspector.Helpers.Editor;
using System;
using UnityEditor;
using UnityEngine;


namespace CustomInspector.Editor
{
    [CustomPropertyDrawer(typeof(DynamicSlider))]
    [CustomPropertyDrawer(typeof(DynamicSliderAttribute))]
    public class DynamicSliderDrawer : TypedPropertyDrawer
    {
#if UNITY_EDITOR
        public DynamicSliderDrawer() : base(nameof(DynamicSliderAttribute) + " can only be used on " + nameof(DynamicSlider),
        typeof(DynamicSlider)
        )
        { }

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            label = PropertyValues.ValidateLabel(label, property);

            if (!TryOnGUI(position, property, label))
                return;

            //Get/test min max
            SerializedProperty min = property.FindPropertyRelative("min");
            SerializedProperty max = property.FindPropertyRelative("max");

            //set the fixed side to default value
            DirtyValue dv = new DirtyValue(property);
            FixedSide fixedSide = (FixedSide)dv.FindRelative("fixedSide").GetValue();
            switch (fixedSide)
            {
                case FixedSide.None:
                    break;
                case FixedSide.FixedMin:
                    float defaultMin = (float)dv.FindRelative("defaultMin").GetValue();
                    if (min.floatValue != defaultMin)
                        min.floatValue = defaultMin;
                    break;
                case FixedSide.FixedMax:
                    float defaultMax = (float)dv.FindRelative("defaultMax").GetValue();
                    if (max.floatValue != defaultMax)
                        max.floatValue = defaultMax;
                    break;
                default:
                    throw new NotImplementedException(fixedSide.ToString());
            }

            //test valid range
            if (min.floatValue == max.floatValue)
            {
                position.y += DrawProperties.messageBoxStartSpacing;
                position.height = DrawProperties.messageBoxHeight;
                DrawProperties.DrawMessageField(position, "Dynamic sliders min and max limit are the same", MessageType.Warning);
                position.y += position.height;
            }

            //Draw Label (with foldout)
            position.height = EditorGUIUtility.singleLineHeight;
            property.isExpanded = EditorGUI.Foldout(position, property.isExpanded, label);
            //Draw Slider
            SerializedProperty valueProperty = property.FindPropertyRelative("value");
            Rect sliderRect = new(x: position.x + EditorGUIUtility.labelWidth,
                                  y: position.y,
                                  width: position.width - EditorGUIUtility.labelWidth,
                                  height: EditorGUIUtility.singleLineHeight);
            EditorGUI.BeginChangeCheck();
            float res = EditorGUI.Slider(sliderRect, valueProperty.floatValue, min.floatValue, max.floatValue);
            if (EditorGUI.EndChangeCheck())
            {
                valueProperty.floatValue = res;
                valueProperty.serializedObject.ApplyModifiedProperties();
            }



            if (property.isExpanded)
            {
                using (new EditorGUI.IndentLevelScope(1))
                {

                    if (fixedSide != FixedSide.FixedMin)
                    {
                        position.y += position.height;
                        EditorGUI.BeginChangeCheck();
                        res = Math.Min(max.floatValue, EditorGUI.FloatField(position, new GUIContent("Custom Min", "Change the min value of the slider above"), min.floatValue));
                        if (EditorGUI.EndChangeCheck())
                        {
                            min.floatValue = res;
                            min.serializedObject.ApplyModifiedProperties();
                        }
                    }

                    if (fixedSide != FixedSide.FixedMax)
                    {
                        position.y += position.height;
                        EditorGUI.BeginChangeCheck();
                        res = Math.Max(min.floatValue, EditorGUI.FloatField(position, new GUIContent("Custom Max", "Change the max value of the slider above"), max.floatValue));
                        if (EditorGUI.EndChangeCheck())
                        {
                            max.floatValue = res;
                            max.serializedObject.ApplyModifiedProperties();
                        }
                    }
                }
            }


        }
        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            if (!TryGetPropertyHeight(property, label, out float fallbackHeight))
                return fallbackHeight;

            SerializedProperty min = property.FindPropertyRelative("min");
            SerializedProperty max = property.FindPropertyRelative("max");

            float errorHeight = 0;
            if (min.floatValue == max.floatValue)
            {
                errorHeight = DrawProperties.messageBoxHeight + DrawProperties.messageBoxStartSpacing;
            }

            DirtyValue dv = new DirtyValue(property);
            FixedSide fixedSide = (FixedSide)dv.FindRelative("fixedSide").GetValue();

            if (property.isExpanded)
            {
                if (fixedSide == FixedSide.None)
                    return errorHeight + 3 * EditorGUIUtility.singleLineHeight + 3 * EditorGUIUtility.standardVerticalSpacing;
                else //one fixed side
                    return errorHeight + 2 * EditorGUIUtility.singleLineHeight + 2 * EditorGUIUtility.standardVerticalSpacing;
            }
            return errorHeight + EditorGUIUtility.singleLineHeight + EditorGUIUtility.standardVerticalSpacing;
        }
#endif
    }
}