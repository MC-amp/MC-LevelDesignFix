using CustomInspector.Extensions;
using CustomInspector.Helpers;
using CustomInspector.Helpers.Editor;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;


namespace CustomInspector.Editor
{
    /// <summary>
    /// Draws a errorMessage if there are some in MessageDrawer
    /// </summary>
    [CustomPropertyDrawer(typeof(MessageDrawer))]
    [CustomPropertyDrawer(typeof(MessageDrawerAttribute))]
    public class MessageDrawerDrawer : TypedPropertyDrawer
    {
#if UNITY_EDITOR
        public MessageDrawerDrawer() : base(nameof(MessageDrawerAttribute) + " can only be used on " + nameof(MessageDrawer),
        typeof(MessageDrawer)
        )
        { }


        public const int messageSize = 35;

        const float minSize = 350; //size at what the spacing disappears
        const float spacing = 0.2f; //proportion of helpbox start

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            label = PropertyValues.ValidateLabel(label, property);

            if (!TryOnGUI(position, property, label))
                return;

            DirtyValue messages = new DirtyValue(property).FindRelative("messages");

            if (messages.IsExisting)
            {
                var mList = (List<(string content, MessageBoxType type)>)messages.GetValue();
                if (mList != null && mList.Count > 0) // NullCheck is a hotfix for when message drawers serialization breaks and loses all data
                {
                    using (new NewIndentLevel(0))
                    {
                        Rect messageRect = new(position);
                        float space = Mathf.Min(Mathf.Max(position.width - minSize, 0), position.width * spacing);
                        messageRect.x += space;
                        messageRect.width -= space;
                        messageRect.height = messageSize;
                        for (int i = 0; i < mList.Count; i++)
                        {
                            EditorGUI.HelpBox(messageRect, mList[i].content, InternalEditorStylesConvert.ToUnityMessageType(mList[i].type));

                            messageRect.y += messageSize;
                            messageRect.y += EditorGUIUtility.standardVerticalSpacing;
                        }

                    }
                }
            }
            else
            {
                position.height = EditorGUIUtility.singleLineHeight;
                EditorGUI.HelpBox(position, $"MessageDrawer is null", MessageType.Error);
            }
        }
        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            if (!TryGetPropertyHeight(property, label, out float fallbackHeight))
                return fallbackHeight;

            DirtyValue messages = new DirtyValue(property).FindRelative("messages");

            if (messages.IsExisting)
            {
                return (messageSize + EditorGUIUtility.standardVerticalSpacing) * ((IList)messages.GetValue())?.Count ?? 0; // // NullCheck is a hotfix for when message drawers serialization breaks and loses all data
            }
            else
            {
                return EditorGUIUtility.singleLineHeight; //error that messagedrawer is null
            }
        }
#endif
    }
}