using CustomInspector.Extensions;
using System;
using UnityEditor;
using UnityEngine;

namespace CustomInspector.Editor
{
    [CustomPropertyDrawer(typeof(HideFieldAttribute))]
    public class HideFieldAttributeDrawer : PropertyDrawer
    {
        static bool isGlobalDisabled = false;

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            label = PropertyValues.ValidateLabel(label, property);

            if (!isGlobalDisabled)
            {
                if (property.IsArrayElement()) //is element in a list
                {
                    position.height = DrawProperties.messageBoxHeight;
                    EditorGUI.HelpBox(position, "Use [HideInInspector] to hide the whole list instead of just the elements", MessageType.Warning); //Pack lists in classes and show classes parallel
                    return;
                }
                else
                {
                    // nothing
                }
            }
            else
            {
                DrawProperties.PropertyField(position, label, property);
            }
        }
        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            if (!isGlobalDisabled)
            {
                if (property.IsArrayElement())
                    return DrawProperties.messageBoxHeight;
                else
                    return -EditorGUIUtility.standardVerticalSpacing;
            }
            else
            {
                return DrawProperties.GetPropertyHeight(label, property);
            }
        }

        public class GlobalDisable : IDisposable
        {
            readonly bool previousState;
            public GlobalDisable(bool isDisabled = true)
            {
                previousState = isGlobalDisabled;
                isGlobalDisabled = isDisabled;
            }

            public void Dispose() => isGlobalDisabled = previousState;
        }
    }
}

