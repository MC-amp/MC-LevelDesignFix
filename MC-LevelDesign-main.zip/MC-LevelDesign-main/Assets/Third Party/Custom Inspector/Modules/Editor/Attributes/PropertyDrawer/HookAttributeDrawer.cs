using CustomInspector.Extensions;
using CustomInspector.Helpers.Editor;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEngine;


namespace CustomInspector.Editor
{
    [CustomPropertyDrawer(typeof(HookAttribute))]
    public class HookAttributeDrawer : PropertyDrawer
    {
        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            label = PropertyValues.ValidateLabel(label, property);

            PropInfo info = cache.GetInfo(property, attribute, fieldInfo);

            if (info.ErrorMessage != null)
            {
                DrawProperties.DrawPropertyWithMessage(position, label, property, info.ErrorMessage, MessageType.Error);
                return;
            }


            if (Selection.count <= 1) //single editing
            {
                object oldValue = property.GetValue();

                EditorGUI.BeginChangeCheck();
                DrawProperties.PropertyField(position, label, property);
                if (EditorGUI.EndChangeCheck())
                {
                    object newValue = property.GetValue();

                    HookAttribute a = (HookAttribute)attribute;
                    if (a.useHookOnly && info.IfExecute())
                    {
                        //Revert change on property
                        property.SetValue(oldValue);
                    }
                    //property to instantiation
                    property.serializedObject.ApplyModifiedProperties();
                    //method on instantiation
                    info.HookMethod(property, oldValue, newValue);
                    //instantiation to property
                    property.serializedObject.ApplyModifiedFields(true);
                }
            }
            else // multiediting
            {
                List<SerializedObject> serializedObjects = property.serializedObject.targetObjects.Select(_ => new SerializedObject(_)).ToList();
                List<SerializedProperty> serializedProperties = serializedObjects.Select(so => so.FindProperty(property.propertyPath)).ToList();
                List<object> oldValues = serializedProperties.Select(p => p.GetValue()).ToList();

                EditorGUI.BeginChangeCheck();
                DrawProperties.PropertyField(position, label, property);
                if (EditorGUI.EndChangeCheck())
                {
                    object newValue = property.GetValue();

                    //remove not changed ones
                    if (property.propertyType != SerializedPropertyType.Generic) //on generics the equals is overridden often, so we cant really know if something changed
                    {
                        for (int i = 0; i < oldValues.Count; i++)
                        {
                            bool equal = oldValues[i] == null ? newValue == null : oldValues[i].Equals(newValue);
                            if (equal)
                            {
                                serializedObjects.RemoveAt(i);
                                serializedProperties.RemoveAt(i);
                                oldValues.RemoveAt(i);
                                i--;
                            }
                        }
                        Debug.Assert(oldValues.Count > 0, $"{nameof(HookAttribute)}: Hook not executed, because new value *equals* old value.");
                    }

                    //revert changes if hook only
                    HookAttribute a = (HookAttribute)attribute;
                    if (a.useHookOnly && info.IfExecute())
                    {
                        //Revert change on property
                        for (int i = 0; i < serializedProperties.Count; i++)
                            serializedProperties[i].SetValue(oldValues[i]);
                    }
                    //property to instantiation
                    foreach (var so in serializedObjects)
                        so.ApplyModifiedProperties();
                    //method on instantiation
                    for (int i = 0; i < serializedProperties.Count; i++)
                        info.HookMethod(serializedProperties[i], oldValues[i], newValue);
                    //instantiation to property
                    foreach (var so in serializedObjects)
                        so.ApplyModifiedFields(true);
                }
            }
        }
        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            PropInfo info = cache.GetInfo(property, attribute, fieldInfo);

            if (info.ErrorMessage != null)
                return DrawProperties.GetPropertyWithMessageHeight(label, property);
            else
                return DrawProperties.GetPropertyHeight(label, property);
        }

        static readonly PropInfoCache<PropInfo> cache = new();

        class PropInfo : ICachedPropInfo
        {
            public string ErrorMessage { get; private set; }
            public int MethodParameterCount { get; private set; } = -1;
            /// <summary> A method that executes on with property, oldValue & newValue </summary>
            public Action<SerializedProperty, object, object> HookMethod { get; private set; }
            /// <summary> Defines, in what scope the attribute will execute (e.g. �n or outside of playing) </summary>
            public Func<bool> IfExecute { get; private set; }
            public PropInfo() { }
            public void Initialize(SerializedProperty property, PropertyAttribute attribute, FieldInfo fieldInfo)
            {
                DirtyValue owner = DirtyValue.GetOwner(property);
                HookAttribute attr = (HookAttribute)attribute;
                Type propertyType = fieldInfo.FieldType;

                InvokableMethod method = null;
                // Find a method without parameters
                if (method == null)
                {
                    if (property.TryGetMethodOnOwner(out method, attr.methodPath, new Type[] { }))
                        MethodParameterCount = 0;
                }
                // Find a method with 1 parameter
                if (method == null)
                {
                    if (property.TryGetMethodOnOwner(out method, attr.methodPath, new Type[] { propertyType }))
                        MethodParameterCount = 1;
                }
                // Find a method with 2 parameters
                if (method == null)
                {
                    if (property.TryGetMethodOnOwner(out method, attr.methodPath, new Type[] { propertyType, propertyType }))
                        MethodParameterCount = 2;
                }

                // Test if any method was found
                if (method == null)
                {
                    ErrorMessage = $"Method '{attr.methodPath}' not found in '{property.GetOwnerAsFinder().Name}' with 0-2 parameters of type '{propertyType.Name}'";
                    return;
                }

                if (MethodParameterCount <= 0 && attr.useHookOnly)
                {
                    ErrorMessage = $"HookAttribute: New inputs are not applied, because you set 'useHookOnly', " +
                            $"but your method on '{attr.methodPath}' did not define 1 or 2 parameters of type {propertyType}";
                    return;
                }

                IfExecute = attr.target switch
                {
                    ExecutionTarget.Always => () => true,
                    ExecutionTarget.IsPlaying => () => Application.isPlaying,
                    ExecutionTarget.IsNotPlaying => () => !Application.isPlaying,
                    _ => throw new NotImplementedException(attr.target.ToString()),
                };


                if (MethodParameterCount == 2)
                {
                    HookMethod = (p, o, n) =>
                    {
                        if (IfExecute())
                        {
                            try
                            {
                                var owner = DirtyValue.GetOwner(p).GetValue();
                                method.Info.Invoke(owner, new object[] { o, n });
                            }
                            catch (Exception e)
                            {
                                Debug.LogException(e);
                            }
                        }
                    };
                }
                else if (MethodParameterCount == 1)
                {
                    HookMethod = (p, o, n) =>
                    {
                        if (IfExecute())
                        {
                            try
                            {
                                var owner = DirtyValue.GetOwner(p).GetValue();
                                method.Info.Invoke(owner, new object[] { n });
                            }
                            catch (Exception e)
                            {
                                Debug.LogException(e);
                            }
                        }
                    };
                }
                else
                {
                    HookMethod = (p, o, n) =>
                    {
                        if (IfExecute())
                        {
                            try
                            {
                                var owner = DirtyValue.GetOwner(p).GetValue();
                                method.Info.Invoke(owner, new object[0]);
                            }
                            catch (Exception e)
                            {
                                Debug.LogException(e);
                            }
                        }
                    };
                }
            }
        }
    }
}
